// Lấy các phần tử DOM
const modal = document.getElementById('productModal');
const closeBtn = document.querySelector('.close-btn');
const cartBtn = document.getElementById('cart-btn');
const cartModal = document.getElementById('cartModal');
const closeCartBtn = document.querySelector('.close-cart-btn');
const cartItemsContainer = document.getElementById('cart-items');
const cartCount = document.getElementById('cart-count');
const cartTotal = document.getElementById('cart-total');
const buyButtons = document.querySelectorAll('.buy-btn');
const detailButtons = document.querySelectorAll('.detail-btn');
const modalImg = document.getElementById('modalImg');
const modalName = document.getElementById('modalName');
const modalPrice = document.getElementById('modalPrice');
const modalDesc = document.getElementById('modalDesc');

let cart = [];

// Hiển thị modal sản phẩm khi nhấn nút "Xem chi tiết"
detailButtons.forEach(button => {
    button.addEventListener('click', () => {
        const name = button.getAttribute('data-name');
        const price = parseFloat(button.getAttribute('data-price'));
        const img = button.getAttribute('data-img');
        const desc = button.getAttribute('data-desc');

        modalImg.src = img;
        modalName.textContent = name;
        modalPrice.textContent = `Giá: ${price}$`;
        modalDesc.textContent = `Mô tả: ${desc}`;
        modal.style.display = 'flex';
    });
});

// Thêm sản phẩm vào giỏ hàng khi nhấn nút "Mua"
buyButtons.forEach(button => {
    button.addEventListener('click', () => {
        const name = button.getAttribute('data-name');
        const price = parseFloat(button.getAttribute('data-price'));
        const img = button.getAttribute('data-img');
        const desc = button.getAttribute('data-desc');

        const product = { name, price, img, desc };
        cart.push(product);
        updateCartCount();
        alert(`Đã thêm ${name} vào giỏ hàng!`);
    });
});

// Đóng modal sản phẩm
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// Hiển thị modal giỏ hàng
cartBtn.addEventListener('click', () => {
    cartModal.style.display = 'block';
    updateCart();
});

// Đóng modal giỏ hàng
closeCartBtn.addEventListener('click', () => {
    cartModal.style.display = 'none';
});

window.addEventListener('click', (event) => {
    if (event.target === cartModal) {
        cartModal.style.display = 'none';
    }
});

// Cập nhật số lượng sản phẩm trong giỏ hàng
function updateCartCount() {
    cartCount.textContent = cart.length;
}

// Cập nhật nội dung giỏ hàng
function updateCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;
        const itemElement = document.createElement('div');
        itemElement.innerHTML = `
            <p>${item.name} - ${item.price}$ 
            <button onclick="removeFromCart(${index})">Xóa</button></p>
        `;
        cartItemsContainer.appendChild(itemElement);
    });

    cartTotal.textContent = `Tổng cộng: ${total.toFixed(2)}$`;
}

// Xóa sản phẩm khỏi giỏ hàng
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartCount();
    updateCart();
}

// Lấy các phần tử cho slide sản phẩm
const productList = document.querySelector('.product-list');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const productCards = document.querySelectorAll('.product-card');
const cardWidth = 280; // Chiều rộng của mỗi card (250px + 30px margin-right)
let currentIndex = 0;
const visibleCards = 3; // Số card hiển thị cùng lúc
const maxIndex = productCards.length - visibleCards;

// Chuyển slide sang trái
prevBtn.addEventListener('click', () => {
    if (currentIndex > 0) {
        currentIndex--;
        productList.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }
});

// Chuyển slide sang phải
nextBtn.addEventListener('click', () => {
    if (currentIndex < maxIndex) {
        currentIndex++;
        productList.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    }
});