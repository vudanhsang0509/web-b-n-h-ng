<?php
// session_start();
// require_once "Connect/Connect.php";

// if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
//     header("location: login/index.php");
//     exit;
// }
?> 

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luxury Jewelry Shop</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style/home.css">
</head>

<body>
    <!-- Navbar -->
    <nav>
        <ul>
            <li><a href="#home">Trang Chủ</a></li>
            <li><a href="#product">Sản Phẩm</a></li>
            <li><a href="#contact">Liên Hệ</a></li>
        </ul>
        <div class="cart-icon">
            <span id="cart-count">0</span>
            <button id="cart-btn">🛒</button>
        </div>
    </nav>

    <!-- Trang Chủ -->
    <section id="home">
        <header class="hero">
            <div class="hero-content">
                <h1>Luxury Jewelry Shop</h1>
                <p>Khám phá vẻ đẹp vĩnh cửu với những món trang sức tinh tế!</p>
            </div>
        </header>
        <!-- Modal giỏ hàng -->
        <div id="cartModal" class="cart-modal">
            <div class="cart-modal-content">
                <span class="close-cart-btn">×</span>
                <h2>Giỏ Hàng</h2>
                <div id="cart-items"></div>
                <p id="cart-total">Tổng cộng: 0$</p>
                <button onclick="alert('Thanh toán thành công!')">Thanh Toán</button>
            </div>
        </div>
        <div class="container">
            <div class="big-image">
                <img src="./img/1.jpg" alt="Trang sức khuyến mãi">
            </div>
            <section class="special-offers">
                <h2>Ưu Đãi Đặc Biệt</h2>
                <div class="products">
                    <div class="product">
                        <img src="./img/1.jpg" alt="Nhẫn Kim Cương">
                        <h3>Nhẫn Kim Cương</h3>
                        <p>Giá gốc: <s>500$</s></p>
                        <p>Giá khuyến mãi: 299$</p>
                        <button class="buy-btn" data-name="Nhẫn Kim Cương" data-price="299$" data-img="./img/1.jpg"
                            data-desc="Kim cương tự nhiên, thiết kế thanh lịch">Mua</button>
                    </div>
                    <div class="product">
                        <img src="./img/1.jpg" alt="Dây Chuyền Ngọc Trai">
                        <h3>Dây Chuyền Ngọc Trai</h3>
                        <p>Giá gốc: <s>300$</s></p>
                        <p>Giá khuyến mãi: 199$</p>
                        <button class="buy-btn" data-name="Dây Chuyền Ngọc Trai" data-price="199$" data-img="./img/1.jpg"
                            data-desc="Ngọc trai cao cấp, phong cách cổ điển">Mua</button>
                    </div>
                    <div class="product">
                        <img src="./img/1.jpg" alt="Bông Tai Vàng">
                        <h3>Bông Tai Vàng</h3>
                        <p>Giá gốc: <s>250$</s></p>
                        <p>Giá khuyến mãi: 149$</p>
                        <button class="buy-btn" data-name="Bông Tai Vàng" data-price="149$" data-img="./img/1.jpg"
                            data-desc="Vàng 18K, kiểu dáng hiện đại">Mua</button>
                    </div>
                </div>
            </section>
        </div>
        <section id="product" class="product-section">
    <h2>Sản Phẩm</h2>
    <div class="slider-wrapper">
        <button class="prev-btn">❮</button>
        <div class="product-container">
            <div class="product-list">
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Vòng Tay Bạc">
                    <h3>Vòng Tay Bạc</h3>
                    <ul>
                        <li>Chất liệu: Bạc 925</li>
                        <li>Đính đá quý cao cấp</li>
                        <li>Thiết kế tinh xảo, sang trọng</li>
                    </ul>
                    <p>Giá bán: 120$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Vòng Tay Bạc" data-price="120$" data-img="./img/1.jpg"
                            data-desc="Bạc cao cấp, đính đá quý lấp lánh">Mua</button>
                        <button class="detail-btn" data-name="Vòng Tay Bạc" data-price="120$" data-img="./img/1.jpg"
                            data-desc="Bạc cao cấp, đính đá quý lấp lánh">Xem chi tiết</button>
                    </div>
                </div>
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Nhẫn Cưới Đôi">
                    <h3>Nhẫn Cưới Đôi</h3>
                    <ul>
                        <li>Chất liệu: Vàng trắng 14K</li>
                        <li>Khắc tên tùy chọn</li>
                        <li>Biểu tượng tình yêu vĩnh cửu</li>
                    </ul>
                    <p>Giá bán: 450$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Nhẫn Cưới Đôi" data-price="450$" data-img="./img/1.jpg"
                            data-desc="Nhẫn đôi vàng trắng, biểu tượng tình yêu vĩnh cửu">Mua</button>
                        <button class="detail-btn" data-name="Nhẫn Cưới Đôi" data-price="450$" data-img="./img/1.jpg"
                            data-desc="Nhẫn đôi vàng trắng, biểu tượng tình yêu vĩnh cửu">Xem chi tiết</button>
                    </div>
                </div>
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Dây Chuyền Kim Cương">
                    <h3>Dây Chuyền Kim Cương</h3>
                    <ul>
                        <li>Kim cương: 1 carat</li>
                        <li>Chất liệu: Vàng 18K</li>
                        <li>Phong cách: Sang trọng</li>
                    </ul>
                    <p>Giá bán: 800$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Dây Chuyền Kim Cương" data-price="800$" data-img="./img/1.jpg"
                            data-desc="Kim cương lộng lẫy, vàng 18K sang trọng">Mua</button>
                        <button class="detail-btn" data-name="Dây Chuyền Kim Cương" data-price="800$" data-img="./img/1.jpg"
                            data-desc="Kim cương lộng lẫy, vàng 18K sang trọng">Xem chi tiết</button>
                    </div>
                </div>
                <!-- Nhân đôi sản phẩm để trượt liền mạch -->
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Vòng Tay Bạc">
                    <h3>Vòng Tay Bạc</h3>
                    <ul>
                        <li>Chất liệu: Bạc 925</li>
                        <li>Đính đá quý cao cấp</li>
                        <li>Thiết kế tinh xảo, sang trọng</li>
                    </ul>
                    <p>Giá bán: 120$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Vòng Tay Bạc" data-price="120$" data-img="./img/1.jpg"
                            data-desc="Bạc cao cấp, đính đá quý lấp lánh">Mua</button>
                        <button class="detail-btn" data-name="Vòng Tay Bạc" data-price="120$" data-img="./img/1.jpg"
                            data-desc="Bạc cao cấp, đính đá quý lấp lánh">Xem chi tiết</button>
                    </div>
                </div>
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Nhẫn Cưới Đôi">
                    <h3>Nhẫn Cưới Đôi</h3>
                    <ul>
                        <li>Chất liệu: Vàng trắng 14K</li>
                        <li>Khắc tên tùy chọn</li>
                        <li>Biểu tượng tình yêu vĩnh cửu</li>
                    </ul>
                    <p>Giá bán: 450$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Nhẫn Cưới Đôi" data-price="450$" data-img="./img/1.jpg"
                            data-desc="Nhẫn đôi vàng trắng, biểu tượng tình yêu vĩnh cửu">Mua</button>
                        <button class="detail-btn" data-name="Nhẫn Cưới Đôi" data-price="450$" data-img="./img/1.jpg"
                            data-desc="Nhẫn đôi vàng trắng, biểu tượng tình yêu vĩnh cửu">Xem chi tiết</button>
                    </div>
                </div>
                <div class="product-card">
                    <img src="./img/1.jpg" alt="Dây Chuyền Kim Cương">
                    <h3>Dây Chuyền Kim Cương</h3>
                    <ul>
                        <li>Kim cương: 1 carat</li>
                        <li>Chất liệu: Vàng 18K</li>
                        <li>Phong cách: Sang trọng</li>
                    </ul>
                    <p>Giá bán: 800$</p>
                    <div class="button-group">
                        <button class="buy-btn" data-name="Dây Chuyền Kim Cương" data-price="800$" data-img="./img/1.jpg"
                            data-desc="Kim cương lộng lẫy, vàng 18K sang trọng">Mua</button>
                        <button class="detail-btn" data-name="Dây Chuyền Kim Cương" data-price="800$" data-img="./img/1.jpg"
                            data-desc="Kim cương lộng lẫy, vàng 18K sang trọng">Xem chi tiết</button>
                    </div>
                </div>
            </div>
        </div>
        <button class="next-btn">❯</button>
    </div>
</section>

    <!-- Trang Liên Hệ -->
    <section id="contact" class="contact-section">
        <div class="contact-info">
            <h1>Liên Hệ</h1>
            <h2>Luxury Jewelry Shop</h2>
            <p>Trang mua sắm trực tuyến trang sức cao cấp.</p>
            <div class="info">
                <p><strong>Địa chỉ:</strong> Tòa nhà Vàng Bạc, Quận 1, TP.HCM</p>
                <p><strong>Điện thoại:</strong> 0909 123 456</p>
                <p><strong>Email:</strong> luxuryjewelry@shop.com</p>
            </div>
        </div>
        <div class="contact-image">
        </div>
    </section>

    <!-- Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <span class="close-btn">×</span>
            <img id="modalImg" src="" alt="Product Image">
            <h3 id="modalName"></h3>
            <p id="modalPrice"></p>
            <p id="modalDesc"></p>
            <button onclick="alert('Đã thêm vào giỏ hàng!')">Thêm vào giỏ hàng</button>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>© 2025 Luxury Jewelry Shop. All rights reserved.</p>
        <div class="social-links">
            <a href="#">Facebook</a> |
            <a href="#">Instagram</a> |
            <a href="#">Twitter</a>
        </div>
        <p>Designed with ❤️ for jewelry lovers</p>
    </footer>

    <script src="./js/app.js"></script>
</body>

</html>