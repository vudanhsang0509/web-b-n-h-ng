<?php
session_start();
require_once "../Connect/Connect.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$register_error = $register_success = "";
if (isset($_POST["register"])) {
    $full_name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    
    if (empty($full_name) || empty($email) || empty($password)) {
        $_SESSION['register_error'] = "Please fill all fields";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['register_error'] = "Invalid email format";
    } else {
        $stmt = $conn->prepare("SELECT id FROM customers WHERE email = ?");
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $_SESSION['register_error'] = "Email already exists";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO customers (full_name, email, password) VALUES (?, ?, ?)");
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("sss", $full_name, $email, $hashed_password);
            if ($stmt->execute()) {
                $_SESSION['register_success'] = "Registration successful! Please login.";
            } else {
                $_SESSION['register_error'] = "Something went wrong. Please try again.";
            }
        }
        $stmt->close();
    }
    $conn->close();
    header("location: index.php");
    exit;
}