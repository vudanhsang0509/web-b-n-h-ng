<?php
session_start();
require_once "../Connect/Connect.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$login_error = "";
if (isset($_POST["login"])) {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    
    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = "Please fill all fields";
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, email, password FROM customers WHERE email = ?");
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user["password"])) {
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $user["id"];
                $_SESSION["full_name"] = $user["full_name"];
                $conn->close();
                header("location: ../home.php");
                exit;
            } else {
                $_SESSION['login_error'] = "Invalid password";
            }
        } else {
            $_SESSION['login_error'] = "Email not found";
        }
        $stmt->close();
    }
    $conn->close();
    header("location: index.php");
    exit;
}