const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

document.addEventListener("DOMContentLoaded", function () {
    document.querySelector('form[action="register.php"]').addEventListener("submit", function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        fetch("register.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById("register-msg").innerText = data;
        });
    });

    document.querySelector('form[action="login.php"]').addEventListener("submit", function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        fetch("login.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById("login-msg").innerText = data;
            if (data.includes("Đăng nhập thành công")) {
                setTimeout(() => {
                    window.location.href = "dashboard.php"; // Chuyển hướng sau khi đăng nhập thành công
                }, 1000);
            }
        });
    });
});
